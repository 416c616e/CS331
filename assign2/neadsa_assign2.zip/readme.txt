I've implemented a random player, to utilize it simply specify 'random' instead of 'human' or 'minimax'
